import React from 'react'

const NotFoundText = () => {
  return (
    <p className='w-full text-center font-semibold text-xl text-slate-700 dark:text-white mt-20'>Notes Not Found :(</p>
  )
}

export default NotFoundText